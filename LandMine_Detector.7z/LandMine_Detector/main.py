from flask import Flask, render_template_string, request, jsonify
import RPi.GPIO as GPIO
import serial
import threading

app = Flask(__name__)

# ---------------- MOTOR PINS ----------------
ENA, IN1, IN2, IN3, IN4, ENB = 18,23,24,27,22,13
SENSOR = 17

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

motor_pins = [ENA,IN1,IN2,IN3,IN4,ENB]
for pin in motor_pins:
    GPIO.setup(pin, GPIO.OUT)

GPIO.setup(SENSOR, GPIO.IN, pull_up_down=GPIO.PUD_UP)

pwmA = GPIO.PWM(ENA,1000)
pwmB = GPIO.PWM(ENB,1000)
pwmA.start(0)
pwmB.start(0)

speed = 50

# ---------------- MOTOR CONTROL ----------------
def stop():
    GPIO.output(IN1,0); GPIO.output(IN2,0)
    GPIO.output(IN3,0); GPIO.output(IN4,0)
    pwmA.ChangeDutyCycle(0)
    pwmB.ChangeDutyCycle(0)

def move(direction):
    if GPIO.input(SENSOR)==0:
        stop()
        return

    if direction=="forward":
        GPIO.output(IN1,1); GPIO.output(IN2,0)
        GPIO.output(IN3,1); GPIO.output(IN4,0)
    elif direction=="backward":
        GPIO.output(IN1,0); GPIO.output(IN2,1)
        GPIO.output(IN3,0); GPIO.output(IN4,1)
    elif direction=="right":
        GPIO.output(IN1,0); GPIO.output(IN2,1)
        GPIO.output(IN3,1); GPIO.output(IN4,0)
    elif direction=="left":
        GPIO.output(IN1,1); GPIO.output(IN2,0)
        GPIO.output(IN3,0); GPIO.output(IN4,1)
    elif direction=="stop":
        stop()
        return

    pwmA.ChangeDutyCycle(speed)
    pwmB.ChangeDutyCycle(speed)

# ---------------- GPS ----------------
gps = serial.Serial("/dev/serial0",9600,timeout=1)
gps_data = {"lat":None,"lon":None}

def convert(raw,dir):
    if not raw: return None
    deg = float(raw[:2])
    mins = float(raw[2:])
    dec = deg + mins/60
    if dir in ['S','W']:
        dec*=-1
    return round(dec,6)

def read_gps():
    global gps_data
    while True:
        line = gps.readline().decode(errors='ignore')
        if "$GPRMC" in line:
            parts=line.split(",")
            if parts[3] and parts[5]:
                gps_data["lat"]=convert(parts[3],parts[4])
                gps_data["lon"]=convert(parts[5],parts[6])

threading.Thread(target=read_gps,daemon=True).start()

# ---------------- ROUTES ----------------
@app.route("/")
def home():
    return render_template_string(HTML)

@app.route("/control",methods=["POST"])
def control():
    global speed
    speed=int(request.form.get("speed"))
    direction=request.form.get("direction")
    move(direction)
    return ("",204)

@app.route("/status")
def status():
    mine = GPIO.input(SENSOR)==0
    if mine:
        stop()
    return jsonify({
        "mine":mine,
        "lat":gps_data["lat"],
        "lon":gps_data["lon"]
    })

# ---------------- WEBPAGE ----------------
HTML="""
<!DOCTYPE html>
<html>
<head>
<title>Smart Defense Vehicle</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

<style>
body{
margin:0;
font-family:Arial;
background:linear-gradient(135deg,#000428,#004e92);
color:white;
text-align:center;
}
h1{padding:10px;}

button{
width:90px;height:50px;margin:5px;
border:none;border-radius:10px;
font-size:16px;
cursor:pointer;
}
.forward{background:#4CAF50;}
.backward{background:#f44336;}
.left{background:#2196F3;}
.right{background:#ff9800;}
.stop{background:black;color:white;}

#map{
height:40vh;
width:90%;
margin:auto;
border-radius:20px;
}

.alert{
display:none;
background:red;
padding:15px;
font-size:22px;
margin:10px;
border-radius:15px;
animation:blink 1s infinite;
}
@keyframes blink{
50%{opacity:0.3;}
}
</style>
</head>
<body>

<h1>🚗 Smart Landmine Detection Vehicle</h1>

<div class="alert" id="alertBox">⚠ LANDMINE DETECTED - VEHICLE STOPPED ⚠</div>

<div>
<button class="forward" onclick="send('forward')">⬆</button><br>
<button class="left" onclick="send('left')">⬅</button>
<button class="stop" onclick="send('stop')">⏹</button>
<button class="right" onclick="send('right')">➡</button><br>
<button class="backward" onclick="send('backward')">⬇</button>
</div>

<br>
Speed:<br>
<input type="range" min="0" max="100" value="50" id="speedSlider">

<h3>🛰 Live GPS Location</h3>
<div id="map"></div>

<script>
var map=L.map('map').setView([20,78],5);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
maxZoom:19}).addTo(map);
var marker=L.marker([20,78]).addTo(map);

function send(dir){
let speed=document.getElementById("speedSlider").value;
fetch("/control",{
method:"POST",
headers:{"Content-Type":"application/x-www-form-urlencoded"},
body:`direction=${dir}&speed=${speed}`
});
}

function update(){
fetch("/status")
.then(r=>r.json())
.then(data=>{
if(data.mine){
document.getElementById("alertBox").style.display="block";
}else{
document.getElementById("alertBox").style.display="none";
}
if(data.lat && data.lon){
marker.setLatLng([data.lat,data.lon]);
map.setView([data.lat,data.lon],17);
}
});
}
setInterval(update,2000);
</script>

</body>
</html>
"""

if __name__=="__main__":
    app.run(host="0.0.0.0",port=5000)